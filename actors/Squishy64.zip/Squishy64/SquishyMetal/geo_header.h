extern const GeoLayout SquishyMetal;_geo[];
extern Lights1 SquishyMetal_Fast3D_Material_lights;
extern u8 SquishyMetal_metal_rgba16[];
extern Vtx SquishyMetal_0000_displaylist_mesh_layer_1_vtx_0[159];
extern Gfx SquishyMetal_0000_displaylist_mesh_layer_1_tri_0[];
extern Gfx mat_SquishyMetal_Fast3D_Material[];
extern Gfx mat_revert_SquishyMetal_Fast3D_Material[];
extern Gfx SquishyMetal_0000_displaylist_mesh_layer_1[];
